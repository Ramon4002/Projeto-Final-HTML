<?php
    // Inclui o arquivo de configuração para conectar ao banco de dados
    include_once('config.php');

    // Verifica se o parâmetro 'id' não está vazio na URL
    if (!empty($_GET['id'])) {
        // Obtém o valor 'id' da URL
        $id = $_GET['id'];
        
        // Cria uma consulta SQL para selecionar dados da tabela 'usuarios' onde o 'id' corresponda
        $sqlSelect = "SELECT * FROM usuarios WHERE id=$id";
        
        // Executa a consulta e armazena o resultado
        $result = $conexao->query($sqlSelect);
        
        // Se houver linhas retornadas (ou seja, o usuário com o 'id' especificado existe)
        if ($result->num_rows > 0) {
            // Obtém os dados do usuário e armazena em variáveis
            while ($user_data = mysqli_fetch_assoc($result)) {
                $nome = $user_data['nome'];
                $email = $user_data['email'];
                $telefone = $user_data['telefone'];
                $sexo = $user_data['sexo'];
                $data_nasc = $user_data['data_nasc'];
                $cidade = $user_data['cidade'];
                $estado = $user_data['estado'];
                $matricula = $user_data['matricula'];
            }
        } else {
            // Redireciona para 'sistema.php' se o usuário não for encontrado
            header('Location: sistema.php');
        }
    } else {
        // Redireciona para 'sistema.php' se o 'id' não estiver na URL
        header('Location: sistema.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário | GN</title>
    <link rel="stylesheet" href="css/edit.css">
</head>
<body>
    <a href="sistema.php">Voltar</a>
    <div class="princip">
        <div class="forma-container">
            <form action="saveEdit.php" method="POST">
                <fieldset>
                    <legend><b>Editar Cliente</b></legend>
                    <br>
                    <!-- Campo de entrada para o nome -->
                    <div class="inputBox">
                        <label for="nome" class="labelInput">Nome completo</label><br>
                        <input type="text" name="nome" id="nome" class="inputUser" value="<?php echo htmlspecialchars($nome); ?>" required>
                    </div>
                    <br>
                    <!-- Campo de entrada para a senha -->
                    <div class="inputBox">
                        <label for="senha" class="labelInput">Senha</label><br>
                        <input type="text" name="senha" id="senha" class="inputUser" value="<?php echo htmlspecialchars($senha); ?>" required>
                    </div>
                    <br>
                    <!-- Campo de entrada para o email -->
                    <div class="inputBox">
                        <label for="email" class="labelInput">Email</label><br>
                        <input type="email" name="email" id="email" class="inputUser" value="<?php echo htmlspecialchars($email); ?>" required>
                    </div>
                    <br>
                    <!-- Campo de entrada para o telefone -->
                    <div class="inputBox">
                        <label for="telefone" class="labelInput">Telefone</label>
                        <input type="tel" name="telefone" id="telefone" class="inputUser" value="<?php echo htmlspecialchars($telefone); ?>" required>
                    </div>
                    <!-- Seleção de gênero -->
                    <p>Sexo:</p>
                    <input type="radio" id="feminino" name="genero" value="feminino" <?php echo ($sexo == 'feminino') ? 'checked' : ''; ?> required>
                    <label for="feminino">Feminino</label>
                    <br>
                    <input type="radio" id="masculino" name="genero" value="masculino" <?php echo ($sexo == 'masculino') ? 'checked' : ''; ?> required>
                    <label for="masculino">Masculino</label>
                    <br>
                    <input type="radio" id="outro" name="genero" value="outro" <?php echo ($sexo == 'outro') ? 'checked' : ''; ?> required>
                    <label for="outro">Outro</label>
                    <br><br>
                    <!-- Campo de entrada para a data de nascimento -->
                    <div class="inputBox">
                        <label for="data_nascimento"><b>Data de Nascimento:</b></label><br>
                        <input type="date" name="data_nascimento" id="data_nascimento" class="inputUser" value="<?php echo htmlspecialchars($data_nasc); ?>" required>
                    </div>
                    <br>
                    <!-- Campo de entrada para a cidade -->
                    <div class="inputBox">
                        <label for="cidade" class="labelInput">Cidade</label><br>
                        <input type="text" name="cidade" id="cidade" class="inputUser" value="<?php echo htmlspecialchars($cidade); ?>" required>
                    </div>
                    <br>
                    <!-- Campo de entrada para o estado -->
                    <div class="inputBox">
                        <label for="estado" class="labelInput">Estado</label><br>
                        <input type="text" name="estado" id="estado" class="inputUser" value="<?php echo htmlspecialchars($estado); ?>" required>
                    </div>
                    <br>
                    <!-- Campo de entrada para a matrícula -->
                    <div class="inputBox">
                        <label for="matricula" class="labelInput">Matrícula</label><br>
                        <input type="number" name="matricula" id="matricula" class="inputUser" value="<?php echo htmlspecialchars($matricula); ?>" required>
                    </div>
                    <br>
                    <!-- Campo oculto para o ID -->
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
                    <!-- Botão de envio -->
                    <input type="submit" name="update" id="submit">
                </fieldset>
            </form>
        </div>
    </div>
</body>
</html>


