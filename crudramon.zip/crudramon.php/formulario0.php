<?php

    if(isset($_POST['submit']))
    {
        include_once('config.php');

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        $telefone = $_POST['telefone'];
        $sexo = $_POST['genero'];
        $data_nasc = $_POST['data_nascimento'];
        $cidade = $_POST['cidade'];
        $estado = $_POST['estado'];
        $matricula = $_POST['matricula'];

        $result = mysqli_query($conexao, "INSERT INTO usuarios(nome,senha,email,telefone,sexo,data_nasc,cidade,estado,matricula) 
        VALUES ('$nome','$senha','$email','$telefone','$sexo','$data_nasc','$cidade','$estado','$matricula')");
        header('Location: sistema.php');
        
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="css/formulario2.css">
    <script src="js/movendo.js"></script>
</head>
<body>
    <a href="#" id="sairLink">Voltar</a>
    <div class="princip">
        <div class="forma-container">
            <form action="formulario0.php" method="POST">
                <fieldset>
                    <legend><b>Cadastro de Alunos</b></legend>
                    <div class="inputBox">
                        <label for="nome" class="labelInput">Nome completo</label>
                        <input type="text" name="nome" id="nome" class="inputUser" required>
                    </div>
                    <div class="inputBox">
                        <label for="senha" class="labelInput">Senha</label>
                        <input type="password" name="senha" id="senha" class="inputUser" required>
                    </div>
                    <div class="inputBox">
                        <label for="email" class="labelInput">Email</label>
                        <input type="email" name="email" id="email" class="inputUser" required>
                    </div>
                    <div class="inputBox">
                        <label for="telefone" class="labelInput">Telefone</label>
                        <input type="tel" name="telefone" id="telefone" class="inputUser" required>
                    </div>
                    <p>Sexo:</p>
                    <input type="radio" id="feminino" name="genero" value="feminino" required>
                    <label for="feminino">Feminino</label>
                    <input type="radio" id="masculino" name="genero" value="masculino" required>
                    <label for="masculino">Masculino</label>
                    <input type="radio" id="outro" name="genero" value="outro" required>
                    <label for="outro">Outro</label>
                    <label for="data_nascimento"><b>Data de Nascimento:</b></label>
                    <br><input type="date" name="data_nascimento" id="data_nascimento" required>
                    <div class="inputBox">
                        <label for="cidade" class="labelInput">Cidade</label>
                        <input type="text" name="cidade" id="cidade" class="inputUser" required>
                    </div>
                    <div class="inputBox">
                        <label for="estado" class="labelInput">Estado</label>
                        <input type="text" name="estado" id="estado" class="inputUser" required>
                    </div>
                    <div class="inputBox">
                        <label for="cpf" class="labelInput">CPF</label>
                        <input type="number" name="cpf" id="cpf" class="inputUser"required>
                    </div>
                    <input type="submit" id="submit" name="submit">
                    </fieldset>
        </form>
        </div>
    </div>
</body>
</html>